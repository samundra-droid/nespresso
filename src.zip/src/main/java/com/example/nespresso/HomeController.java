package com.example.nespresso;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@Controller
public class HomeController {

    private final ProductService productService;

    public HomeController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/")
    public String home() {
        return "home"; // This will correspond to templates/home.html
    }

    @GetMapping("/shop")
    public String shop(Model model) {
        // Fetch products from the database
        List<Product> products = productService.getAllProducts();
        // Add products to the model to pass to the shop.html view
        model.addAttribute("products", products);
        return "shop"; // This will correspond to templates/shop.html
    }
}
