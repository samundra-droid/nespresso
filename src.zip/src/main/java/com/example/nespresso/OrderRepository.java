package com.example.nespresso;


import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    // Custom query to find orders by email
    List<Order> findByUserEmail(String email);
}
