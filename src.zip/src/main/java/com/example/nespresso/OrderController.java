package com.example.nespresso;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/order-success")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public String orderSuccess() {
        return "order-success"; // Returns the order success view
    }

    @GetMapping("/history") // Mapping to view the order history
    public String orderHistory(Principal principal, Model model) {
        String userEmail = principal.getName(); // Get the user's email from the principal
        List<Order> orderHistory = orderService.getOrdersByEmail(userEmail); // Fetch order history
        model.addAttribute("orderHistory", orderHistory); // Add to model
        return "order-history"; // Render order-history.html
    }

    // Optional: Endpoint to create a test order (remove if not needed)
    @PostMapping("/create")
    public String createOrder(Principal principal) {
        String userEmail = principal.getName();
        Order newOrder = new Order();
        newOrder.setUserEmail(userEmail);
        newOrder.setStatus("Completed");
        newOrder.setTotalAmount(100.0); // Example total amount
        orderService.saveOrder(newOrder); // Save order
        return "redirect:/order-success"; // Redirects to order success page
    }
}
