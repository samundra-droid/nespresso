package com.example.nespresso;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class OrderService {
    private final OrderRepository orderRepository;
    private final ProductService productService;

    @Autowired
    public OrderService(OrderRepository orderRepository, ProductService productService) {
        this.orderRepository = orderRepository;
        this.productService = productService;
    }

    public void saveOrder(Order order) {
        System.out.println("Saving Order: " + order);
        orderRepository.save(order);
        System.out.println("Order saved successfully!");
    }

    public List<Order> getOrdersByEmail(String email) {
        return orderRepository.findByUserEmail(email);
    }

    public Order createAndSaveOrder(String userEmail, Map<Long, Integer> cart) {
        Order newOrder = new Order();
        newOrder.setUserEmail(userEmail);
        newOrder.setStatus("Pending");
        double totalAmount = 0;

        for (Map.Entry<Long, Integer> entry : cart.entrySet()) {
            Product product = productService.getProductById(entry.getKey());
            if (product != null) {
                totalAmount += product.getPrice() * entry.getValue();
                OrderItem orderItem = new OrderItem();
                orderItem.setProduct(product);
                orderItem.setQuantity(entry.getValue());
                orderItem.setOrder(newOrder); // Associate the order item with the order
                newOrder.addOrderItem(orderItem); // Add item to order
            }
        }

        newOrder.setTotalAmount(totalAmount);
        saveOrder(newOrder);
        return newOrder;
    }
}
