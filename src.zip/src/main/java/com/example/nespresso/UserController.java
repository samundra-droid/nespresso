package com.example.nespresso;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Show the signup form
    @GetMapping("/signup")
    public String signupForm(Model model) {
        model.addAttribute("user", new User());
        return "signup"; // Show signup page
    }

    // Process the signup
    @PostMapping("/signup")
    public String signup(@ModelAttribute User user) {
        userService.saveUser(user);
        return "redirect:/login"; // Redirect to login after signup
    }

    // Show the login form
    @GetMapping("/login")
    public String loginForm() {
        return "login"; // Show login page
    }

    // Process the login and redirect based on the user type (admin or user)
    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password, Model model, HttpSession session) {
        User user = userService.findByEmail(email);

        if (user != null && user.getPassword().equals(password)) { // Verify password
            model.addAttribute("user", user); // Add user details to the model
            session.setAttribute("userEmail", user.getEmail()); // Store user email in session

            // Check if there's a product ID stored in the session for adding to the cart
            Long productIdToAdd = (Long) session.getAttribute("productIdToAdd");
            if (productIdToAdd != null) {
                // Redirect to add product to cart and clear the session attribute
                session.removeAttribute("productIdToAdd");
                return "redirect:/cart/add?productId=" + productIdToAdd; // Redirect to add the product to cart
            }

            // Check the user type and redirect accordingly
            if ("admin".equals(user.getUserType())) {
                return "redirect:/admin/products"; // Redirect admins to products page
            } else {
                return "redirect:/cart"; // Redirect users to cart page
            }
        } else {
            model.addAttribute("error", "Invalid email or password");
            return "login"; // Return to login page if login fails
        }
    }
}
