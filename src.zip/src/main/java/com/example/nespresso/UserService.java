package com.example.nespresso;

import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Save the user, ensuring the role is set to 'user' if not already set
    public void saveUser(User user) {
        if (user.getUserType() == null || user.getUserType().isEmpty()) {
            user.setUserType("user"); // Assign 'user' role by default
        }
        userRepository.save(user);
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
}
