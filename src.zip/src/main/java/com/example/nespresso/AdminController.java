package com.example.nespresso;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private final ProductService productService;

    public AdminController(ProductService productService) {
        this.productService = productService;
    }

    // Display all products
    @GetMapping("/products")
    public String viewProducts(Model model) {
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
        return "products"; // Make sure you have products.html
    }

    // Show form to add a new product
    @GetMapping("/add-product")
    public String showAddProductForm(Model model) { // Renamed method for clarity
        model.addAttribute("product", new Product());
        return "add-products"; // Corrected to match your HTML file name
    }

    // Handle adding a new product
    @PostMapping("/add-product")
    public String addProduct(@ModelAttribute Product product, @RequestParam("image") MultipartFile image) {
        productService.saveProduct(product, image); // Save product and image
        return "redirect:/admin/products"; // Redirect to product list after adding
    }

    // Show form to edit an existing product
    @GetMapping("/edit-product/{id}")
    public String editProductForm(@PathVariable Long id, Model model) {
        Product product = productService.getProductById(id);
        model.addAttribute("product", product);
        return "edit-products"; // Corrected to match your HTML file name
    }

    // Handle editing an existing product, including image upload
    @PostMapping("/edit-product/{id}")
    public String editProduct(@PathVariable Long id, @ModelAttribute Product product, @RequestParam(value = "image", required = false) MultipartFile image) {
        productService.updateProduct(id, product, image); // Update product and image if provided
        return "redirect:/admin/products"; // Redirect to product list after editing
    }

    // Handle deleting a product
    @GetMapping("/delete-product/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id); // Delete the product
        return "redirect:/admin/products"; // Redirect to product list after deletion
    }
}
