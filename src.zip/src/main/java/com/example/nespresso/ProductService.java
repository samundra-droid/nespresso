package com.example.nespresso;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

@Service
public class ProductService {
    private final ProductRepository productRepository;
    private final String uploadDir = "uploads/";

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // Retrieve all products
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // Retrieve product by ID
    public Product getProductById(Long id) {
        return productRepository.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
    }

    // Save product with optional image upload
    public void saveProduct(Product product, MultipartFile image) {
        if (!image.isEmpty()) {
            try {
                // Save image to 'uploads' directory
                Files.createDirectories(Paths.get(uploadDir));
                String filePath = uploadDir + image.getOriginalFilename();
                Files.copy(image.getInputStream(), Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
                product.setImageUrl("/" + filePath); // Store image URL in product
            } catch (IOException e) {
                throw new RuntimeException("Failed to store image", e);
            }
        }
        productRepository.save(product);
    }

    // Update product with optional image update
    public void updateProduct(Long id, Product updatedProduct, MultipartFile image) {
        Product existingProduct = productRepository.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));

        // Update product fields
        existingProduct.setName(updatedProduct.getName());
        existingProduct.setDescription(updatedProduct.getDescription());
        existingProduct.setPrice(updatedProduct.getPrice());

        if (!image.isEmpty()) {
            try {
                // Save new image
                String filePath = uploadDir + image.getOriginalFilename();
                Files.copy(image.getInputStream(), Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
                existingProduct.setImageUrl("/" + filePath); // Update image URL
            } catch (IOException e) {
                throw new RuntimeException("Failed to update image", e);
            }
        }

        productRepository.save(existingProduct);
    }

    // Delete product by ID
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

}
