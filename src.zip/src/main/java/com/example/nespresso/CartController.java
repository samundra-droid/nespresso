package com.example.nespresso;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/cart")
public class CartController {
    private final ProductService productService;
    private final OrderService orderService; // Inject OrderService

    @Autowired
    public CartController(ProductService productService, OrderService orderService) {
        this.productService = productService;
        this.orderService = orderService; // Initialize OrderService
    }

    @PostMapping("/add")
    public String addToCart(@RequestParam Long productId,
                            @RequestParam(required = false, defaultValue = "1") int quantity,
                            HttpSession session) {
        // Retrieve or create the cart in session
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart == null) {
            cart = new HashMap<>(); // Use Map to keep productId and quantity
        }

        // Find the product by ID
        Product product = productService.getProductById(productId);
        if (product != null) {
            // Update quantity or add new product to cart
            cart.put(productId, cart.getOrDefault(productId, 0) + quantity);
            session.setAttribute("cart", cart);
        }

        return "redirect:/cart"; // Redirect to view cart
    }

    @GetMapping
    public String viewCart(HttpSession session, Model model) {
        // Retrieve the cart from session
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart == null) {
            cart = new HashMap<>();
        }

        // Calculate total cost
        double total = cart.entrySet().stream()
                .mapToDouble(entry -> productService.getProductById(entry.getKey()).getPrice() * entry.getValue())
                .sum();

        // Add to model
        model.addAttribute("cart", cart);
        model.addAttribute("total", total);
        model.addAttribute("productService", productService);

        return "cart";
    }

    @PostMapping("/update-item")
    public String updateCartItem(@RequestParam Long id, @RequestParam int quantity, HttpSession session) {
        // Retrieve the cart from session
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart != null && cart.containsKey(id)) {
            if (quantity <= 0) {
                cart.remove(id); // Remove item if quantity is zero or less
            } else {
                cart.put(id, quantity); // Update the quantity
            }
            session.setAttribute("cart", cart);
        }

        return "redirect:/cart"; // Redirect back to the cart
    }

    @PostMapping("/remove-item")
    public String removeCartItem(@RequestParam Long id, HttpSession session) {
        // Retrieve the cart from session
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart != null) {
            cart.remove(id); // Remove the item from cart
            session.setAttribute("cart", cart);
        }

        return "redirect:/cart"; // Redirect back to the cart
    }

    @PostMapping("/increase-quantity")
    public String increaseQuantity(@RequestParam Long id, HttpSession session) {
        // Retrieve the cart from session
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart != null && cart.containsKey(id)) {
            cart.put(id, cart.get(id) + 1); // Increase the quantity by 1
            session.setAttribute("cart", cart);
        }
        return "redirect:/cart"; // Redirect to view cart
    }

    @PostMapping("/decrease-quantity")
    public String decreaseQuantity(@RequestParam Long id, HttpSession session) {
        // Retrieve the cart from session
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart != null && cart.containsKey(id)) {
            int currentQuantity = cart.get(id);
            if (currentQuantity > 1) {
                cart.put(id, currentQuantity - 1); // Decrease the quantity by 1
            } else {
                cart.remove(id); // Remove item if quantity becomes zero
            }
            session.setAttribute("cart", cart);
        }
        return "redirect:/cart"; // Redirect to view cart
    }

    @PostMapping("/checkout")
    public String proceedToCheckout(HttpSession session) {
        String userEmail = (String) session.getAttribute("userEmail");
        if (userEmail == null) {
            return "redirect:/login"; // Redirect if not logged in
        }

        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart != null && !cart.isEmpty()) {
            // Create the order based on the cart contents
            Order order = orderService.createAndSaveOrder(userEmail, cart);
            System.out.println("Order placed successfully with ID: " + order.getId());
        }

        session.removeAttribute("cart"); // Clear cart after saving
        return "redirect:/order/success"; // Redirect to success page
    }
}
